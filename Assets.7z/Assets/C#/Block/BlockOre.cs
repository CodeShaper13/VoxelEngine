﻿public class BlockOre : Block {

}
