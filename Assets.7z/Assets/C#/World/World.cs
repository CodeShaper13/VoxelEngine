﻿using UnityEngine;
using System.Collections.Generic;

public class World : MonoBehaviour {
    //Dictionary of all loaded chunks with a WorldPos as the key
    public Dictionary<BlockPos, Chunk> loadedChunks = new Dictionary<BlockPos, Chunk>();

    public string worldName;
    public long seed = 0;
    public WorldGenerator worldGenerator;

    public GameObject chunkPrefab;
    public GameObject itemPrefab;

    private Transform chunkWrapper;
    private Transform itemWrapper;

    void Awake() {
        this.worldName = "world";
        this.worldGenerator = new WorldGenerator(this, this.seed);

        this.chunkWrapper = new GameObject().transform;
        this.chunkWrapper.parent = this.transform;
        this.chunkWrapper.name = "CHUNKS";
        this.itemWrapper = new GameObject().transform;
        this.itemWrapper.parent = this.transform;
        this.itemWrapper.name = "ITEMS";
    }

    void LateUpdate() {
        foreach(Chunk c in this.loadedChunks.Values) {
            c.updateChunk();
        }

        if (Input.GetKeyDown(KeyCode.R)) {
            this.saveWorld();
        }
    }

    public void spawnItem(ItemStack stack, Vector3 pos, Quaternion rot) {
        GameObject g = GameObject.Instantiate(this.itemPrefab);
        g.transform.parent = this.itemWrapper;
        g.transform.rotation = rot;
        g.transform.position = pos;
        EntityItem i = g.GetComponent<EntityItem>();
        i.stack = stack;
        i.initRendering();
    }

    //Loads a new chunk, loading it if the save exists, otherwise we generate a new one.
    public Chunk loadChunk(BlockPos pos) {
        GameObject newChunkObject = Instantiate(chunkPrefab, pos.toVector(), Quaternion.identity) as GameObject;
        newChunkObject.transform.parent = this.chunkWrapper;
        Chunk chunk = newChunkObject.GetComponent<Chunk>();
        chunk.initChunk(this, pos);

        //Add it to the chunks dictionary with the position as the key
        loadedChunks.Add(pos, chunk);

        if(!Serialization.loadChunk(chunk)) {
            this.worldGenerator.generateChunk(chunk);
        }
        return chunk;
    }

    //Unloads a chunk, removing references and saving it
    public void unloadChunk(BlockPos pos) {
        Chunk chunk = null;
        if (loadedChunks.TryGetValue(pos, out chunk)) {
            //Serialization.SaveChunk(chunk);
            Object.Destroy(chunk.gameObject);
            loadedChunks.Remove(pos);
        }
    }

    public Chunk getChunk(BlockPos pos) {
        pos.x = Mathf.FloorToInt(pos.x / (float)Chunk.SIZE) * Chunk.SIZE;
        pos.y = Mathf.FloorToInt(pos.y / (float)Chunk.SIZE) * Chunk.SIZE;
        pos.z = Mathf.FloorToInt(pos.z / (float)Chunk.SIZE) * Chunk.SIZE;

        Chunk chunk = null;
        loadedChunks.TryGetValue(pos, out chunk);
        return chunk;
    }

    //Returns the chunk at x, y, z (World coordinates)
    public Chunk getChunk(int x, int y, int z) {
        return this.getChunk(new BlockPos(x, y, z));
    }

    public Block getBlock(BlockPos pos) {
        return this.getBlock(pos.x, pos.y, pos.z);
    }

    public Block getBlock(int x, int y, int z) {
        Chunk chunk = this.getChunk(x, y, z);
        if (chunk != null) {
            return chunk.getBlock(x - chunk.pos.x, y - chunk.pos.y, z - chunk.pos.z);
        }
        else {
            return Block.air;
        }
    }

    public void setBlock(BlockPos pos, Block block, bool runUpdate = true) {
        this.setBlock(pos.x, pos.y, pos.z, block, runUpdate);
    }

    public void setBlock(int x, int y, int z, Block block, bool runUpdate = true) {
        Chunk chunk = this.getChunk(x, y, z);
        if (chunk != null) {
            chunk.setBlock(x - chunk.pos.x, y - chunk.pos.y, z - chunk.pos.z, block);

            if(runUpdate) {
                BlockPos p = new BlockPos(x, y, z);
                foreach (Direction d in Direction.all) {
                    BlockPos p1 = p.move(d);
                    this.getBlock(p1).onNeighborChange(p, d);
                    chunk = this.getChunk(p1.x, p1.y, p1.z);
                    if(chunk != null) {
                        chunk.dirty = true;
                    }
                }
            }
            //this.UpdateIfEqual(x - chunk.pos.x, 0,              new BlockPos(x - 1, y, z));
            //this.UpdateIfEqual(x - chunk.pos.x, Chunk.SIZE - 1, new BlockPos(x + 1, y, z));
            //this.UpdateIfEqual(y - chunk.pos.y, 0,              new BlockPos(x, y - 1, z));
            //this.UpdateIfEqual(y - chunk.pos.y, Chunk.SIZE - 1, new BlockPos(x, y + 1, z));
            //this.UpdateIfEqual(z - chunk.pos.z, 0,              new BlockPos(x, y, z - 1));
            //this.UpdateIfEqual(z - chunk.pos.z, Chunk.SIZE - 1, new BlockPos(x, y, z + 1));        
        }
    }

    public byte getMeta(BlockPos pos) {
        return this.getMeta(pos.x, pos.y, pos.z);
    }

    public byte getMeta(int x, int y, int z) {
        Chunk chunk = this.getChunk(x, y, z);
        return chunk != null ? chunk.getMeta(x - chunk.pos.x, y - chunk.pos.y, z - chunk.pos.z) : (byte)0;
    }

    public void setMeta(BlockPos pos, byte meta) {
        this.setMeta(pos.x, pos.y, pos.z, meta);
    }

    public void setMeta(int x, int y, int z, byte meta) {
        Chunk chunk = this.getChunk(x, y, z);
        if (chunk != null) {
            BlockPos p = new BlockPos(x, y, z);
            chunk.setMeta(x - chunk.pos.x, y - chunk.pos.y, z - chunk.pos.z, meta);
            if(chunk.getBlock(x - chunk.pos.x, y - chunk.pos.y, z - chunk.pos.z).dirtyAfterMetaChange(p, meta)) {
                chunk.dirty = true;
            }

            foreach (Direction d in Direction.all) {
                BlockPos p1 = p.move(d);
                this.getBlock(p1).onNeighborChange(p, d);
            }
        }
    }

    //What's this do?
    void updateIfEqual(int value1, int value2, BlockPos pos) {
        if (value1 == value2) {
            Chunk chunk = getChunk(pos);
            if (chunk != null) {
                chunk.dirty = true;
            }
        }
    }

    //Saves the world and all loaded chunks.
    public void saveWorld() {
        List<Chunk> tempChunkList = new List<Chunk>();
        foreach (Chunk c in this.loadedChunks.Values) {
            tempChunkList.Add(c);
        }
        foreach (Chunk c in tempChunkList) {
            Serialization.saveChunk(c);
            Object.Destroy(c.gameObject);
            loadedChunks.Remove(c.pos);
        }
    }
}
