﻿public class WorldGeneratorFlat : WorldGenerator {

    public WorldGeneratorFlat(World world, long seed) : base(world, seed) {

    }

    public override void generateChunk(Chunk chunk) {
        for (int x = 0; x < Chunk.SIZE; x++) {
            for (int z = 0; z < Chunk.SIZE; z++) {
                for (int y = chunk.pos.y; y < chunk.pos.y + Chunk.SIZE; y++) {
                    Block b = y < 16 ? Block.stone : y < 18 ? Block.dirt : y < 19 ? Block.grass : Block.air;
                    chunk.setBlock(x, y - chunk.pos.y, z, b);
                }
            }
        }
    }
}
