﻿public class WorldGenerator {

    public World world;
    public long seed;

    public WorldGenerator(World world, long seed) {
        this.world = world;
        this.seed = seed;
    }

    public virtual void generateChunk(Chunk chunk) {
        new TerrainGen().ChunkGen(chunk);
    }

    public virtual void populateChunk(Chunk chunk) {
        chunk.populated = true;
        //TODO
    }
}
