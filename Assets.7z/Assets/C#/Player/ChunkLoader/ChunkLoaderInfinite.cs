﻿using UnityEngine;
using System.Collections.Generic;

public class ChunkLoaderInfinite : ChunkLoader {

    public override void updateLoader() {
        if (!this.initialUpdate) {
            var temp = Time.time;
            this.loadChunks(this.getOccupiedChunkPos());
            Debug.Log("Time for MyExpensiveFunction: " + (Time.realtimeSinceStartup - temp).ToString("f6"));

            this.initialUpdate = true;
        }

        BlockPos p = this.getOccupiedChunkPos();
        if (p.x != this.previousOccupiedChunkPos.x || p.y != this.previousOccupiedChunkPos.y || p.z != this.previousOccupiedChunkPos.z) {
            this.loadChunks(p);
        }
        this.previousOccupiedChunkPos = p;

        if (this.buildChunks(this.maxBuiltPerLoop) == 0) {
            this.unloadChunks(p);
        }
    }

    protected override void unloadChunks(BlockPos occupiedChunkPos) {
        occupiedChunkPos.x *= 16;
        occupiedChunkPos.y *= 16;
        occupiedChunkPos.z *= 16;

        List<BlockPos> removals = new List<BlockPos>();
        foreach (Chunk c in this.world.loadedChunks.Values) {
            BlockPos p = c.pos;
            if (this.toFarOnAxis(occupiedChunkPos.x, p.x) || this.toFarOnAxis(occupiedChunkPos.y, p.y) || this.toFarOnAxis(occupiedChunkPos.z, p.z)) {
                removals.Add(c.pos);
            }
        }
        foreach (BlockPos p in removals) {
            this.world.unloadChunk(p);
        }
    }

    protected override void loadChunks(BlockPos occupiedChunkPos) {
        occupiedChunkPos.x *= 16;
        occupiedChunkPos.y *= 16;
        occupiedChunkPos.z *= 16;

        //Add all the chunks close to the player to the list of chunks to generate.
        for (int i = -this.loadRadius; i < this.loadRadius + 1; i++) {
            for (int j = -this.loadRadius; j < this.loadRadius + 1; j++) {
                for (int k = -this.loadRadius; k < this.loadRadius + 1; k++) {
                    int x = i * Chunk.SIZE + occupiedChunkPos.x;
                    int y = k * Chunk.SIZE + occupiedChunkPos.y;
                    int z = j * Chunk.SIZE + occupiedChunkPos.z;

                    Chunk c = world.getChunk(x, y, z);
                    BlockPos p = new BlockPos(x, y, z);
                    if (c == null && !this.buildList.Contains(p)) {
                        this.buildList.Add(p);
                    }
                }
            }
        }
    }
}